# fact_checker

Checks a single factual claim: looks it up in existing fact-check
databases first, falls back to weighing general web evidence, and shows
you the full citation trail behind whatever verdict it gives.

## Quick start (works with zero setup, in limited mode)

```bash
pip install -r requirements.txt   # currently empty — stdlib only
python3 webapp.py
# open http://localhost:8000
```

With no API keys set, the site still runs, but it tells you it's in
"limited mode" — see below for why that matters.

## Recommended setup (API keys)

None of these cost anything to obtain at the tier this project needs, but
you do need your own account for each:

| Env var | What it does | Get one at |
|---|---|---|
| `GOOGLE_FACT_CHECK_API_KEY` | Looks up existing fact-checks (PolitiFact, Snopes, FactCheck.org, etc. via Google's index) — the single highest-value key to add | [Google Cloud Console](https://console.cloud.google.com/) → enable "Fact Check Tools API" → create an API key |
| `SERPER_API_KEY` | Real web search for the fallback path, replacing the fragile no-key scrape | [serper.dev](https://serper.dev) |
| `ANTHROPIC_API_KEY` | Uses Claude to judge whether a web result actually supports/contradicts the claim, instead of a keyword heuristic | [console.anthropic.com](https://console.anthropic.com) — this is your own paid key, separate from any chat subscription |

```bash
export GOOGLE_FACT_CHECK_API_KEY=xxxxx
export SERPER_API_KEY=xxxxx
export ANTHROPIC_API_KEY=xxxxx
python3 webapp.py
```

## CLI usage (no web server)

```python
from fact_checker import check_claim
verdict = check_claim("The Great Wall of China is visible from space with the naked eye")
print(verdict.label, verdict.confidence)
for e in verdict.evidence:
    print(" -", e.stance, e.source_name, e.url)
```

## How a verdict is produced

1. Query `GOOGLE_FACT_CHECK_API_KEY` for existing fact-checks of the claim.
2. If any exist, weight-average their normalized ratings by publisher
   reliability — if fact-checkers disagree, that disagreement is reported,
   not hidden.
3. If none exist, search the web (Serper if configured, otherwise a
   best-effort DuckDuckGo scrape) and score each result's stance toward
   the claim (LLM-based if `ANTHROPIC_API_KEY` is set, keyword heuristic
   otherwise), weighted by source reliability.
4. Aggregate into one of: `TRUE`, `MOSTLY_TRUE`, `MIXED`, `MOSTLY_FALSE`,
   `FALSE`, `UNPROVEN` (evidence found but inconclusive), `UNVERIFIED`
   (no evidence found at all).

## Known limitations — read before trusting output

- **Rating normalization is approximate.** Fact-checking orgs don't share
  one rating scale — "False," "Pants on Fire," and "Incorrect" get mapped
  onto the same normalized label by pattern-matching, which is inherently
  lossy. An unrecognized rating phrase defaults to `UNPROVEN` rather than
  guessing.
- **The no-key web search fallback is fragile.** It scrapes DuckDuckGo's
  HTML page, which isn't a stable public API and can break without notice.
  Get a `SERPER_API_KEY` if you want this to be reliable.
- **The keyword-based stance detector is weak.** It cannot understand
  negation scope, sarcasm, or complex sentence structure reliably. Set
  `ANTHROPIC_API_KEY` for meaningfully better results here.
- **Reliability scores are a starting point, not a rating system.**
  Same caveat as the bias-tracker project's source list — edit
  `reliability.json` to reflect your own judgment.
- **This tool surfaces evidence — it doesn't replace reading it.** Every
  verdict comes with citations specifically so you can check the
  reasoning yourself rather than trusting a label blindly.
