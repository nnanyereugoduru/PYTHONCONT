#!/usr/bin/env python3
"""
webapp.py — A single-claim fact-checking website.

Same design principle as the bias_tracker project: this file contains no
fact-checking logic of its own. It imports fact_checker.py and renders its
output, so the website can never drift out of sync with the underlying
pipeline.

Run:
    export GOOGLE_FACT_CHECK_API_KEY=your_key_here   # optional but recommended
    export SERPER_API_KEY=your_key_here              # optional, better web fallback
    export ANTHROPIC_API_KEY=your_key_here            # optional, better stance detection
    python3 webapp.py
    # open http://localhost:8000

With no API keys set at all, the app still runs — it falls back to the
no-key DuckDuckGo scrape and the keyword-heuristic stance detector, both of
which are explicitly weaker. The site tells you which mode it's running in.
"""

from __future__ import annotations

import argparse
import html
import os
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

import fact_checker as fc

STYLE = """
body { font-family: system-ui, sans-serif; max-width: 760px; margin: 2rem auto; line-height: 1.5; padding: 0 1rem; color: #1a1a1a; }
h1 { margin-bottom: 0.25rem; }
.summary { color: #555; margin-top: 0; }
form.search { display: flex; gap: 0.5rem; margin-bottom: 1rem; }
form.search input[type=text] { flex: 1; padding: 0.6rem; font-size: 1rem; border: 1px solid #ccc; border-radius: 6px; }
form.search button { padding: 0.6rem 1.2rem; font-size: 1rem; border: none; border-radius: 6px; background: #0b5fa5; color: white; cursor: pointer; }
form.search button:hover { background: #084a82; }
.mode-banner { background: #fff8e1; border: 1px solid #f2c94c; border-radius: 6px; padding: 0.6rem 1rem; font-size: 0.85rem; margin-bottom: 1.5rem; }
.verdict { border-radius: 10px; padding: 1.2rem; margin-bottom: 1.5rem; }
.verdict h2 { margin: 0 0 0.3rem 0; }
.verdict .conf { font-size: 0.85rem; color: #555; }
.label-TRUE, .label-MOSTLY_TRUE { background: #e6f4ea; border: 1px solid #34a853; }
.label-FALSE, .label-MOSTLY_FALSE { background: #fce8e6; border: 1px solid #ea4335; }
.label-MIXED { background: #fef7e0; border: 1px solid #f9ab00; }
.label-UNPROVEN, .label-UNVERIFIED { background: #f1f3f4; border: 1px solid #9aa0a6; }
.evidence-item { border: 1px solid #ddd; border-radius: 8px; padding: 0.8rem 1rem; margin-bottom: 0.7rem; }
.stance { font-size: 0.7rem; font-weight: bold; padding: 2px 6px; border-radius: 4px; color: white; margin-right: 0.4rem; }
.stance.supports { background: #34a853; }
.stance.contradicts { background: #ea4335; }
.stance.neutral { background: #9aa0a6; }
.kind { font-size: 0.7rem; color: #888; }
small { color: #777; }
a { color: #0b5fa5; }
nav a { text-decoration: none; color: #0b5fa5; font-size: 0.9rem; }
"""

PAGE_HEADER = """<!doctype html><html><head><meta charset="utf-8">
<title>Fact Checker</title>
<style>{style}</style></head><body>
<nav><a href="/">&larr; New search</a></nav>
<h1>Fact Checker</h1>
<p class="summary">Type a specific, checkable claim &mdash; not an opinion or prediction.</p>
<form class="search" method="get" action="/search">
  <input type="text" name="claim" placeholder="e.g. 'The Great Wall of China is visible from space'" value="{claim}" required>
  <button type="submit">Check</button>
</form>
{mode_banner}
"""


def mode_banner() -> str:
    has_google = bool(os.environ.get("GOOGLE_FACT_CHECK_API_KEY"))
    has_serper = bool(os.environ.get("SERPER_API_KEY"))
    if has_google and has_serper:
        return ""  # running in full-strength mode, no need to nag
    missing = []
    if not has_google:
        missing.append("GOOGLE_FACT_CHECK_API_KEY (fact-check database lookup)")
    if not has_serper:
        missing.append("SERPER_API_KEY (reliable web search — currently using a fragile no-key fallback)")
    items = "".join(f"<li>{m}</li>" for m in missing)
    return f'<div class="mode-banner">Running in limited mode — missing: <ul>{items}</ul>See README.md to add these.</div>'


def render_page(body: str, claim: str = "") -> str:
    header = PAGE_HEADER.format(style=STYLE, claim=html.escape(claim, quote=True), mode_banner=mode_banner())
    return f"{header}{body}</body></html>"


def render_verdict(verdict: fc.Verdict) -> str:
    esc = lambda s: html.escape(s, quote=True)
    label_display = verdict.label.replace("_", " ").title()

    evidence_html = ""
    for e in verdict.evidence:
        rating_line = f'<div><small>Rating: <strong>{esc(e.rating_text)}</strong></small></div>' if e.rating_text else ""
        date_line = f' &middot; {e.date[:10]}' if e.date else ""
        evidence_html += f"""
        <div class="evidence-item">
          <span class="stance {e.stance}">{e.stance.upper()}</span>
          <span class="kind">[{e.kind.replace('_', ' ')}]</span>
          <div><a href="{esc(e.url)}" target="_blank" rel="noopener">{esc(e.snippet[:160])}</a></div>
          {rating_line}
          <small>{esc(e.source_name)} &middot; reliability {e.reliability:.2f}{date_line}</small>
        </div>"""

    return f"""
    <div class="verdict label-{verdict.label}">
      <h2>{label_display}</h2>
      <div class="conf">Confidence: {verdict.confidence:.0%} &mdash; based on evidence weight, not a guarantee of truth</div>
      <p>{esc(verdict.reasoning)}</p>
    </div>
    <h3>Evidence ({len(verdict.evidence)})</h3>
    {evidence_html or '<p>No evidence to show.</p>'}
    <p><small>Always read the linked sources yourself — this tool surfaces evidence, it doesn't replace judgment.</small></p>
    """


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def _send_html(self, content: str, status: int = 200):
        encoded = content.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def do_GET(self):
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)

        if parsed.path == "/":
            self._send_html(render_page("<p>Enter a claim above to see what evidence says about it.</p>"))
            return

        if parsed.path == "/search":
            claim = (params.get("claim", [""])[0]).strip()
            if not claim:
                self._send_html(render_page("<p>Please enter a claim.</p>"), status=400)
                return
            try:
                started = time.time()
                verdict = fc.check_claim(claim)
                elapsed = time.time() - started
                body = render_verdict(verdict)
                body += f'<p><small>Checked in {elapsed:.1f}s.</small></p>'
                self._send_html(render_page(body, claim=claim))
            except Exception as e:
                self._send_html(render_page(f"<p>Something went wrong: {html.escape(str(e))}</p>", claim=claim),
                                 status=500)
            return

        self._send_html(render_page("<p>Not found.</p>"), status=404)


def main():
    parser = argparse.ArgumentParser(description="Serve the fact-checker website locally.")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--host", default="localhost")
    args = parser.parse_args()

    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"Serving at http://{args.host}:{args.port}  (Ctrl+C to stop)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping.")
        server.shutdown()


if __name__ == "__main__":
    main()
