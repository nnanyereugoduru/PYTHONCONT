#!/usr/bin/env python3
"""
fact_checker.py — Core logic for checking a single factual claim.

Pipeline for a claim:
  1. Query Google's Fact Check Tools API for existing fact-checks (best
     evidence — someone already did the work).
  2. If nothing relevant is found, fall back to general web search for
     primary-source evidence.
  3. Score each piece of evidence for stance (supports/contradicts/neutral)
     and weight it by source reliability.
  4. Aggregate into a verdict + confidence + full citation trail.

HONESTY NOTES (read before trusting output):
- Google's `textualRating` field is free text set by each fact-checking
  org, not a fixed scale ("False" vs "Mostly False" vs "Pants on Fire" vs
  "Incorrect" all mean similar-but-not-identical things). Normalizing
  these into one scale is a best-effort heuristic, not a precise mapping.
- The no-API-key web search fallback scrapes DuckDuckGo's HTML results
  page. This is unofficial, could break if DDG changes their markup, and
  should not be hit at high volume. For production use, plug in a real
  search API key (see WebSearchConfig below).
- Stance detection defaults to a keyword heuristic, which is genuinely
  weak — it can be fooled by negation, sarcasm, or complex sentences. Set
  ANTHROPIC_API_KEY to use Claude for this step instead, which reads
  evidence far more reliably. Either way, always read the cited evidence
  yourself — this tool surfaces evidence, it does not replace judgment.
"""

from __future__ import annotations

import json
import logging
import os
import re
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode, urlparse, quote_plus
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
log = logging.getLogger("fact_checker")

HTTP_TIMEOUT = 10
USER_AGENT = "fact-checker/1.0 (educational project)"

CONFIG_PATH = Path(__file__).with_name("reliability.json")
CACHE_PATH = Path(__file__).with_name(".fact_checker_cache.json")
CACHE_TTL_SECONDS = 60 * 60 * 6  # 6 hours — fact-check results don't churn fast

# --------------------------------------------------------------------------
# Source reliability table (NOT political bias — a separate axis entirely).
# 1.0 = primary source / gov data / established wire service.
# 0.5 = general news outlet, generally edited but not primary.
# 0.2 = user-generated / unmoderated / satire-adjacent.
# This is, like SOURCE_BIAS in the other project, a simplified starting
# point — edit reliability.json to reflect your own judgment.
# --------------------------------------------------------------------------

SOURCE_RELIABILITY: dict[str, float] = {
    "reuters.com": 0.95,
    "apnews.com": 0.95,
    "bls.gov": 1.0,
    "census.gov": 1.0,
    "cdc.gov": 1.0,
    "who.int": 0.95,
    "nih.gov": 1.0,
    "nasa.gov": 1.0,
    "snopes.com": 0.85,
    "politifact.com": 0.85,
    "factcheck.org": 0.85,
    "bbc.co.uk": 0.85,
    "npr.org": 0.85,
    "nytimes.com": 0.75,
    "washingtonpost.com": 0.75,
    "wsj.com": 0.75,
    "theguardian.com": 0.75,
    "wikipedia.org": 0.6,  # tertiary source: useful pointer, not a primary citation
}
DEFAULT_RELIABILITY = 0.4  # unknown domain — treat cautiously, not zero


def load_reliability_table() -> dict[str, float]:
    table = dict(SOURCE_RELIABILITY)
    if CONFIG_PATH.exists():
        try:
            data = json.loads(CONFIG_PATH.read_text())
            table.update(data.get("source_reliability", {}))
        except Exception as e:
            log.warning("Could not parse %s: %s", CONFIG_PATH, e)
    return table


def reliability_for_domain(domain: str, table: dict[str, float]) -> float:
    for known_domain, score in table.items():
        if domain == known_domain or domain.endswith("." + known_domain):
            return score
    return DEFAULT_RELIABILITY


# --------------------------------------------------------------------------
# HTTP helper (stdlib only — no `requests` dependency needed for this project)
# --------------------------------------------------------------------------

def _http_get(url: str) -> str | None:
    req = Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urlopen(req, timeout=HTTP_TIMEOUT) as resp:
            return resp.read().decode("utf-8", errors="replace")
    except (URLError, HTTPError) as e:
        log.warning("Request failed for %s: %s", url, e)
        return None


# --------------------------------------------------------------------------
# Data model
# --------------------------------------------------------------------------

@dataclass(frozen=True)
class Evidence:
    source_domain: str
    source_name: str
    url: str
    snippet: str
    reliability: float
    stance: str  # "supports" | "contradicts" | "neutral"
    kind: str    # "fact_check" | "web_search"
    rating_text: str | None = None   # raw textualRating, only for fact_check evidence
    date: str | None = None


@dataclass
class Verdict:
    claim: str
    label: str          # TRUE | MOSTLY_TRUE | MIXED | MOSTLY_FALSE | FALSE | UNPROVEN | UNVERIFIED
    confidence: float   # 0-1, how much evidence backs this label, not "how true"
    evidence: list[Evidence]
    reasoning: str

    def to_json(self) -> dict:
        return {
            "claim": self.claim,
            "label": self.label,
            "confidence": round(self.confidence, 2),
            "reasoning": self.reasoning,
            "evidence": [
                {**e.__dict__} for e in self.evidence
            ],
        }


# --------------------------------------------------------------------------
# Step 1: existing fact-checks via Google Fact Check Tools API
# --------------------------------------------------------------------------

RATING_TO_LABEL = [
    # (regex patterns to look for in textualRating, normalized label)
    (r"pants.on.fire|completely false|totally false|100% false|fabricated|hoax", "FALSE"),
    (r"^false$|incorrect|not true|false claim|debunked", "FALSE"),
    (r"mostly false|mostly incorrect|misleading", "MOSTLY_FALSE"),
    (r"mixture|mixed|partly true|partly false|half true|needs context", "MIXED"),
    (r"mostly true|mostly correct|mostly accurate", "MOSTLY_TRUE"),
    (r"^true$|correct|accurate|confirmed|verified", "TRUE"),
    (r"unproven|unverified|no evidence|insufficient evidence", "UNPROVEN"),
]


def normalize_rating(rating_text: str) -> str:
    """Best-effort mapping of free-text ratings to a fixed label set.
    See module docstring: this is inherently approximate."""
    text = rating_text.lower().strip()
    for pattern, label in RATING_TO_LABEL:
        if re.search(pattern, text):
            return label
    return "UNPROVEN"  # unrecognized rating text — don't guess confidently


def query_fact_check_api(claim: str, api_key: str) -> list[Evidence]:
    params = {"query": claim, "key": api_key, "languageCode": "en", "pageSize": 10}
    url = f"https://factchecktools.googleapis.com/v1alpha1/claims:search?{urlencode(params)}"
    raw = _http_get(url)
    if raw is None:
        return []

    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        log.warning("Fact Check API returned non-JSON response")
        return []

    if "error" in data:
        log.warning("Fact Check API error: %s", data["error"].get("message", data["error"]))
        return []

    reliability_table = load_reliability_table()
    evidence = []
    for claim_obj in data.get("claims", []):
        for review in claim_obj.get("claimReview", []):
            publisher = review.get("publisher", {})
            site = publisher.get("site", "")
            label = normalize_rating(review.get("textualRating", ""))
            stance = {
                "TRUE": "supports", "MOSTLY_TRUE": "supports",
                "FALSE": "contradicts", "MOSTLY_FALSE": "contradicts",
            }.get(label, "neutral")

            evidence.append(Evidence(
                source_domain=site,
                source_name=publisher.get("name", site or "Unknown"),
                url=review.get("url", ""),
                snippet=review.get("title", "") or claim_obj.get("text", ""),
                reliability=reliability_for_domain(site, reliability_table) if site else 0.85,
                stance=stance,
                kind="fact_check",
                rating_text=review.get("textualRating"),
                date=review.get("reviewDate"),
            ))
    return evidence


# --------------------------------------------------------------------------
# Step 2: fallback web search (only runs if step 1 found nothing)
# --------------------------------------------------------------------------

@dataclass
class WebSearchConfig:
    """If you have a real search API key (Bing, Serper, Brave, etc.), wire
    it in here instead of relying on the DuckDuckGo scrape fallback — it
    will be far more stable. This project ships with the free/no-key path
    only, clearly marked as best-effort."""
    serper_api_key: str | None = os.environ.get("SERPER_API_KEY")


def _search_via_serper(claim: str, api_key: str) -> list[dict]:
    """Serper.dev wraps Google Search results; requires SERPER_API_KEY."""
    req = Request(
        "https://google.serper.dev/search",
        data=json.dumps({"q": claim}).encode(),
        headers={"X-API-KEY": api_key, "Content-Type": "application/json", "User-Agent": USER_AGENT},
    )
    try:
        with urlopen(req, timeout=HTTP_TIMEOUT) as resp:
            data = json.loads(resp.read().decode())
    except (URLError, HTTPError) as e:
        log.warning("Serper search failed: %s", e)
        return []
    return [
        {"title": r.get("title", ""), "url": r.get("link", ""), "snippet": r.get("snippet", "")}
        for r in data.get("organic", [])[:8]
    ]


def _search_via_duckduckgo_html(claim: str) -> list[dict]:
    """No-key fallback. Unofficial — scrapes DDG's HTML results page.
    Fragile by nature: if this stops returning results, DDG likely changed
    their markup. Swap in a real API key via WebSearchConfig instead."""
    url = f"https://html.duckduckgo.com/html/?q={quote_plus(claim)}"
    raw = _http_get(url)
    if not raw:
        return []

    results = []
    # DDG's HTML results wrap each result in a <a class="result__a"> title
    # link, followed by a <a class="result__snippet"> for the summary.
    # This is deliberately loose regex, not a full HTML parser, so it
    # degrades gracefully rather than crashing if markup shifts slightly.
    link_pattern = re.findall(
        r'result__a[^>]*href="([^"]+)"[^>]*>(.*?)</a>.*?result__snippet[^>]*>(.*?)</a>',
        raw, re.DOTALL,
    )
    for href, title, snippet in link_pattern[:8]:
        clean = lambda s: re.sub(r"<[^>]+>", "", s).strip()
        results.append({"title": clean(title), "url": href, "snippet": clean(snippet)})
    return results


def web_search_evidence(claim: str, config: WebSearchConfig) -> list[Evidence]:
    if config.serper_api_key:
        raw_results = _search_via_serper(claim, config.serper_api_key)
    else:
        raw_results = _search_via_duckduckgo_html(claim)

    reliability_table = load_reliability_table()
    evidence = []
    for r in raw_results:
        domain = urlparse(r["url"]).netloc.lower().removeprefix("www.")
        if not domain or not r["snippet"]:
            continue
        evidence.append(Evidence(
            source_domain=domain,
            source_name=domain,
            url=r["url"],
            snippet=r["snippet"],
            reliability=reliability_for_domain(domain, reliability_table),
            stance=heuristic_stance(claim, r["snippet"]),
            kind="web_search",
        ))
    return evidence


# --------------------------------------------------------------------------
# Stance detection
# --------------------------------------------------------------------------

CONTRADICT_CUES = re.compile(
    r"\b(false|incorrect|debunk|hoax|myth|no evidence|not true|denies|refutes|disproven|fabricated)\b",
    re.IGNORECASE,
)
SUPPORT_CUES = re.compile(
    r"\b(confirmed|true|accurate|verified|correct|according to (official|data)|shows that)\b",
    re.IGNORECASE,
)


def heuristic_stance(claim: str, snippet: str) -> str:
    """Weak keyword-based fallback. This cannot understand negation scope,
    sarcasm, or which claim a cue word is actually about — it is a rough
    signal only. Prefer llm_stance() when an API key is available."""
    if CONTRADICT_CUES.search(snippet):
        return "contradicts"
    if SUPPORT_CUES.search(snippet):
        return "supports"
    return "neutral"


def llm_stance(claim: str, snippet: str, api_key: str) -> str:
    """Ask Claude whether a snippet supports/contradicts/is neutral toward
    a claim. Requires your own Anthropic API key (this is a standalone
    script, not an in-artifact call) — see README for setup."""
    body = json.dumps({
        "model": "claude-sonnet-4-6",
        "max_tokens": 10,
        "messages": [{
            "role": "user",
            "content": (
                f'Claim: "{claim}"\nEvidence snippet: "{snippet}"\n\n'
                'Does this snippet support, contradict, or stay neutral toward the claim? '
                'Reply with exactly one word: supports, contradicts, or neutral.'
            ),
        }],
    }).encode()
    req = Request(
        "https://api.anthropic.com/v1/messages",
        data=body,
        headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
    )
    try:
        with urlopen(req, timeout=HTTP_TIMEOUT) as resp:
            data = json.loads(resp.read().decode())
        text = data["content"][0]["text"].strip().lower()
        if text in ("supports", "contradicts", "neutral"):
            return text
    except Exception as e:
        log.warning("LLM stance call failed, falling back to heuristic: %s", e)
    return heuristic_stance(claim, snippet)


# --------------------------------------------------------------------------
# Aggregation
# --------------------------------------------------------------------------

def aggregate_verdict(claim: str, evidence: list[Evidence]) -> Verdict:
    if not evidence:
        return Verdict(claim=claim, label="UNVERIFIED", confidence=0.0, evidence=[],
                        reasoning="No relevant fact-checks or web evidence were found for this claim.")

    fact_checks = [e for e in evidence if e.kind == "fact_check"]
    if fact_checks:
        # Existing fact-checks are the strongest evidence — weight-average
        # their normalized labels rather than trusting a single one blindly,
        # since different fact-checkers can (and do) disagree.
        label_weights: dict[str, float] = {}
        for e in fact_checks:
            label = normalize_rating(e.rating_text or "")
            label_weights[label] = label_weights.get(label, 0) + e.reliability

        best_label = max(label_weights, key=label_weights.get)
        total_weight = sum(label_weights.values())
        confidence = label_weights[best_label] / total_weight if total_weight else 0.0
        agreement_note = (
            "All fact-checkers agree." if len(label_weights) == 1
            else f"Fact-checkers show some disagreement across {len(label_weights)} rating categories."
        )
        reasoning = (
            f"Based on {len(fact_checks)} existing fact-check(s) from "
            f"{len({e.source_name for e in fact_checks})} publisher(s). {agreement_note}"
        )
        return Verdict(claim=claim, label=best_label, confidence=round(confidence, 2),
                        evidence=fact_checks, reasoning=reasoning)

    # No existing fact-check — fall back to weighing web evidence stances.
    web_evidence = [e for e in evidence if e.kind == "web_search"]
    support_weight = sum(e.reliability for e in web_evidence if e.stance == "supports")
    contradict_weight = sum(e.reliability for e in web_evidence if e.stance == "contradicts")
    total = support_weight + contradict_weight

    if total == 0:
        return Verdict(claim=claim, label="UNPROVEN", confidence=0.0, evidence=web_evidence,
                        reasoning="Web sources were found but none clearly supported or "
                                  "contradicted the claim — treat this as unresolved.")

    if support_weight > contradict_weight:
        label, confidence = "MOSTLY_TRUE", support_weight / total
    elif contradict_weight > support_weight:
        label, confidence = "MOSTLY_FALSE", contradict_weight / total
    else:
        label, confidence = "MIXED", 0.5

    reasoning = (
        f"No existing fact-check found. Based on {len(web_evidence)} web source(s): "
        f"weighted support={support_weight:.2f}, weighted contradiction={contradict_weight:.2f}. "
        "This is weaker evidence than a dedicated fact-check — read the sources yourself."
    )
    return Verdict(claim=claim, label=label, confidence=round(confidence, 2),
                    evidence=web_evidence, reasoning=reasoning)


# --------------------------------------------------------------------------
# Caching
# --------------------------------------------------------------------------

def _load_cache() -> dict:
    if not CACHE_PATH.exists():
        return {}
    try:
        return json.loads(CACHE_PATH.read_text())
    except Exception:
        return {}


def _save_cache(cache: dict) -> None:
    try:
        CACHE_PATH.write_text(json.dumps(cache))
    except Exception as e:
        log.warning("Could not write cache: %s", e)


# --------------------------------------------------------------------------
# Top-level entry point
# --------------------------------------------------------------------------

def check_claim(claim: str, *, use_cache: bool = True, use_llm_stance: bool = False) -> Verdict:
    claim = claim.strip()
    cache = _load_cache() if use_cache else {}
    cache_key = claim.lower()

    if use_cache and cache_key in cache:
        cached = cache[cache_key]
        if time.time() - cached["fetched_at"] < CACHE_TTL_SECONDS:
            payload = cached["verdict"]
            return Verdict(
                claim=payload["claim"], label=payload["label"], confidence=payload["confidence"],
                reasoning=payload["reasoning"],
                evidence=[Evidence(**e) for e in payload["evidence"]],
            )

    google_key = os.environ.get("GOOGLE_FACT_CHECK_API_KEY")
    evidence: list[Evidence] = []

    if google_key:
        evidence = query_fact_check_api(claim, google_key)
    else:
        log.warning("GOOGLE_FACT_CHECK_API_KEY not set — skipping fact-check database lookup.")

    if not evidence:
        anthropic_key = os.environ.get("ANTHROPIC_API_KEY")
        search_config = WebSearchConfig()
        web_evidence = web_search_evidence(claim, search_config)
        if use_llm_stance and anthropic_key:
            web_evidence = [
                Evidence(**{**e.__dict__, "stance": llm_stance(claim, e.snippet, anthropic_key)})
                for e in web_evidence
            ]
        evidence = web_evidence

    verdict = aggregate_verdict(claim, evidence)

    if use_cache:
        cache[cache_key] = {"fetched_at": time.time(), "verdict": verdict.to_json()}
        _save_cache(cache)

    return verdict
